package com.example.recipe_finder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
